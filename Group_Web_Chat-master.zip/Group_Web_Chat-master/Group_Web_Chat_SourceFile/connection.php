<?php
	$conn=mysqli_connect("localhost","root","","chat_app");
	date_default_timezone_set('Asia/Kolkata');
?>